package com.example.inventoryapp_bobby_smith;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.content.ContentValues;
import android.database.Cursor;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.nio.charset.StandardCharsets;


public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "InventoryDB";
    private static final int DATABASE_VERSION = 2;

    // Users table
    public static final String TABLE_USERS = "users";
    public static final String COL_USER_ID = "id";
    public static final String COL_USERNAME = "username";
    public static final String COL_PASSWORD = "password";

    // Inventory table
    public static final String TABLE_INVENTORY = "inventory";
    public static final String COL_ITEM_ID = "item_id";
    public static final String COL_ITEM_NAME = "item_name";
    public static final String COL_QUANTITY = "quantity";

    // Inventory history table
    public static final String TABLE_HISTORY = "inventory_history";
    public static final String COL_HISTORY_ID = "history_id";
    public static final String COL_HISTORY_ITEM_ID = "item_id";
    public static final String COL_HISTORY_ITEM_NAME = "item_name";
    public static final String COL_HISTORY_ACTION = "action_type";
    public static final String COL_HISTORY_QUANTITY = "quantity";
    public static final String COL_HISTORY_TIMESTAMP = "timestamp";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        String createUsersTable = "CREATE TABLE " + TABLE_USERS + " ("
                + COL_USER_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + COL_USERNAME + " TEXT UNIQUE, "
                + COL_PASSWORD + " TEXT)";

        String createInventoryTable = "CREATE TABLE " + TABLE_INVENTORY + " ("
                + COL_ITEM_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + COL_ITEM_NAME + " TEXT, "
                + COL_QUANTITY + " INTEGER)";

        String createHistoryTable = "CREATE TABLE " + TABLE_HISTORY + " ("
                + COL_HISTORY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + COL_HISTORY_ITEM_ID + " INTEGER, "
                + COL_HISTORY_ITEM_NAME + " TEXT, "
                + COL_HISTORY_ACTION + " TEXT, "
                + COL_HISTORY_QUANTITY + " INTEGER, "
                + COL_HISTORY_TIMESTAMP + " DATETIME DEFAULT CURRENT_TIMESTAMP)";

        db.execSQL(createUsersTable);
        db.execSQL(createInventoryTable);
        db.execSQL(createHistoryTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_HISTORY);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_INVENTORY);
        onCreate(db);
    }

    // Hash a password before it is stored or compared in the database.
    private String hashPassword(String password) {

        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");

            byte[] hash = digest.digest(
                    password.getBytes(StandardCharsets.UTF_8));

            StringBuilder hexString = new StringBuilder();

            for (byte b : hash) {
                String hex = Integer.toHexString(0xff & b);

                if (hex.length() == 1) {
                    hexString.append('0');
                }

                hexString.append(hex);
            }

            return hexString.toString();

        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("Unable to hash password", e);
        }
    }
    public boolean addUser(String username, String password) {

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(COL_USERNAME, username);
        values.put(COL_PASSWORD, hashPassword(password));

        long result = db.insert(TABLE_USERS, null, values);
        db.close();

        return result != -1;
    }

    public boolean addItem(String name, int quantity) {

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(COL_ITEM_NAME, name);
        values.put(COL_QUANTITY, quantity);

        long result = db.insert(TABLE_INVENTORY, null, values);

        if (result != -1) {
            addHistoryRecord(db, (int) result, name, "ADD", quantity);
            return true;
        }

        return false;



    }

    public Cursor getAllHistory() {

        SQLiteDatabase db = this.getReadableDatabase();

        return db.rawQuery(
                "SELECT * FROM " + TABLE_HISTORY +
                        " ORDER BY " + COL_HISTORY_ID + " DESC",
                null
        );
    }
    public Cursor getAllItems() {

        SQLiteDatabase db = this.getReadableDatabase();
        return db.rawQuery("SELECT * FROM " + TABLE_INVENTORY, null);
    }

    private void addHistoryRecord(SQLiteDatabase db, int itemId,
                                  String itemName, String actionType,
                                  int quantity) {

        ContentValues values = new ContentValues();

        values.put(COL_HISTORY_ITEM_ID, itemId);
        values.put(COL_HISTORY_ITEM_NAME, itemName);
        values.put(COL_HISTORY_ACTION, actionType);
        values.put(COL_HISTORY_QUANTITY, quantity);

        db.insert(TABLE_HISTORY, null, values);
    }

    public boolean updateItem(int id, String name, int quantity) {

        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put(COL_ITEM_NAME, name);
        values.put(COL_QUANTITY, quantity);

        int result = db.update(
                TABLE_INVENTORY,
                values,
                COL_ITEM_ID + "=?",
                new String[]{String.valueOf(id)}
        );

        if (result > 0) {
            addHistoryRecord(db, id, name, "UPDATE", quantity);
            return true;
        }

        return false;
    }

    // Delete an inventory item while preserving its final state in history.
    public boolean deleteItem(int id) {

        SQLiteDatabase db = this.getWritableDatabase();

        String itemName = "";
        int quantity = 0;

        // Retrieve the item's current information before deleting it.
        Cursor cursor = db.query(
                TABLE_INVENTORY,
                new String[]{COL_ITEM_NAME, COL_QUANTITY},
                COL_ITEM_ID + "=?",
                new String[]{String.valueOf(id)},
                null,
                null,
                null
        );

        // Save the item's name and quantity for the history record.
        if (cursor.moveToFirst()) {
            itemName = cursor.getString(
                    cursor.getColumnIndexOrThrow(COL_ITEM_NAME));

            quantity = cursor.getInt(
                    cursor.getColumnIndexOrThrow(COL_QUANTITY));
        }

        cursor.close();

        // Delete the item from the active inventory.
        int result = db.delete(
                TABLE_INVENTORY,
                COL_ITEM_ID + "=?",
                new String[]{String.valueOf(id)}
        );

        // Record the deletion only if the database operation succeeds.
        if (result > 0) {
            addHistoryRecord(db, id, itemName, "DELETE", quantity);
            return true;
        }

        return false;
    }




    public boolean checkUser(String username, String password) {

        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery(
                "SELECT * FROM " + TABLE_USERS +
                        " WHERE " + COL_USERNAME + "=? AND " + COL_PASSWORD + "=?",
                new String[]{username, hashPassword(password)}
        );

        boolean exists = cursor.getCount() > 0;
        cursor.close();
        db.close();

        return exists;
    }

    // Temporary verification method used to confirm passwords are stored as hashes.
    public Cursor getAllUsersForTesting() {

        SQLiteDatabase db = this.getReadableDatabase();

        return db.rawQuery(
                "SELECT " + COL_USERNAME + ", " + COL_PASSWORD +
                        " FROM " + TABLE_USERS,
                null
        );
    }


}
