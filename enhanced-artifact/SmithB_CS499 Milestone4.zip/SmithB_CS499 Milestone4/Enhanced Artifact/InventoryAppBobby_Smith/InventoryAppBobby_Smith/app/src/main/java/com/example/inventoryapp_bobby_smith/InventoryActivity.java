package com.example.inventoryapp_bobby_smith;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.widget.Button;
import android.database.Cursor;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.EditText;
import android.Manifest;
import android.content.pm.PackageManager;
import android.telephony.SmsManager;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import android.widget.Toast;
import android.content.SharedPreferences;
import java.util.ArrayList;
import android.util.Log;

public class InventoryActivity extends AppCompatActivity {

    private DatabaseHelper dbHelper;
    private LinearLayout inventoryContainer;
    private EditText editName;
    private EditText editQty;
    private EditText editSearch;
    private int editingItemId = -1;
    private static final int SMS_PERMISSION_CODE = 101;
    private ArrayList<InventoryItem> inventoryItems;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);

        dbHelper = new DatabaseHelper(this);
        inventoryContainer = findViewById(R.id.inventoryContainer);

        inventoryItems = new ArrayList<>();

        // Search controls
        editSearch = findViewById(R.id.editSearch);
        Button searchButton = findViewById(R.id.buttonSearch);

        searchButton.setOnClickListener(v -> {

            String searchText = editSearch.getText().toString().trim();

            searchInventory(searchText);
        });

        // Sort control
        Button sortQuantityButton = findViewById(R.id.buttonSortQuantity);

        sortQuantityButton.setOnClickListener(v -> {
            sortInventoryByQuantity();
        });

        // Low-stock filter control
        Button lowStockButton = findViewById(R.id.buttonLowStock);

        lowStockButton.setOnClickListener(v -> {
            filterLowStock();
        });

        loadInventory();

        Button addButton = findViewById(R.id.buttonAddItem);
        editName = findViewById(R.id.editNewItem);
        editQty = findViewById(R.id.editNewQty);

        addButton.setOnClickListener(v -> {

            String name = editName.getText().toString().trim();
            String qtyText = editQty.getText().toString().trim();

            // Validate item name
            if (name.isEmpty()) {
                Toast.makeText(this,
                        "Please enter an item name.",
                        Toast.LENGTH_SHORT).show();
                return;
            }

            // Validate quantity is not blank
            if (qtyText.isEmpty()) {
                Toast.makeText(this,
                        "Please enter a quantity.",
                        Toast.LENGTH_SHORT).show();
                return;
            }

            int qty;

            try {
                qty = Integer.parseInt(qtyText);
            } catch (NumberFormatException e) {
                Toast.makeText(this,
                        "Quantity must be a valid number.",
                        Toast.LENGTH_SHORT).show();
                return;
            }

            // Quantity must be greater than zero
            if (qty <= 0) {
                Toast.makeText(this,
                        "Quantity must be greater than zero.",
                        Toast.LENGTH_SHORT).show();
                return;
            }

            // Add new item or update existing item
            if (editingItemId == -1) {
                dbHelper.addItem(name, qty);
            } else {
                dbHelper.updateItem(editingItemId, name, qty);
                editingItemId = -1;
            }

            // Low inventory trigger
            SharedPreferences prefs = getSharedPreferences("AppPrefs", MODE_PRIVATE);
            int threshold = prefs.getInt("low_threshold", 5);

            if (qty <= threshold) {
                sendLowInventoryAlert(name);
            }

            editName.setText("");
            editQty.setText("");

            loadInventory();
        });

        Button notificationButton = findViewById(R.id.buttonNotifications);

        notificationButton.setOnClickListener(v -> {
            Intent intent = new Intent(InventoryActivity.this, NotificationActivity.class);
            startActivity(intent);
        });

        // Temporary verification output for testing inventory history records.
        Cursor historyCursor = dbHelper.getAllHistory();

        if (historyCursor.moveToFirst()) {
            do {
                String itemName = historyCursor.getString(
                        historyCursor.getColumnIndexOrThrow(DatabaseHelper.COL_HISTORY_ITEM_NAME));

                String action = historyCursor.getString(
                        historyCursor.getColumnIndexOrThrow(DatabaseHelper.COL_HISTORY_ACTION));

                int quantity = historyCursor.getInt(
                        historyCursor.getColumnIndexOrThrow(DatabaseHelper.COL_HISTORY_QUANTITY));

                String timestamp = historyCursor.getString(
                        historyCursor.getColumnIndexOrThrow(DatabaseHelper.COL_HISTORY_TIMESTAMP));

                Log.d("INVENTORY_HISTORY",
                        itemName + " | " + action + " | " + quantity + " | " + timestamp);

            } while (historyCursor.moveToNext());
        }

        historyCursor.close();

        // Temporary verification output to confirm passwords are stored as hashes.
        Cursor userCursor = dbHelper.getAllUsersForTesting();

        if (userCursor.moveToFirst()) {
            do {
                String username = userCursor.getString(
                        userCursor.getColumnIndexOrThrow(DatabaseHelper.COL_USERNAME));

                String storedPassword = userCursor.getString(
                        userCursor.getColumnIndexOrThrow(DatabaseHelper.COL_PASSWORD));

                Log.d("PASSWORD_SECURITY",
                        username + " | Stored value: " + storedPassword);

            } while (userCursor.moveToNext());
        }

        userCursor.close();
    }


    // Permission request
    private void checkSmsPermission() {
        ActivityCompat.requestPermissions(this,
                new String[]{Manifest.permission.SEND_SMS},
                SMS_PERMISSION_CODE);
    }

    // Handle permission result safely
    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           String[] permissions,
                                           int[] grantResults) {

        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == SMS_PERMISSION_CODE) {
            if (grantResults.length > 0
                    && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                // Permission granted — user can now trigger SMS next time
            } else {
                // Permission denied — app continues normally
            }
        }

    }

    // SMS sending method
    private void sendLowInventoryAlert(String itemName) {

        // Always show visible alert (for grading / demo)
        Toast.makeText(this,
                "Low Inventory Alert for " + itemName,
                Toast.LENGTH_LONG).show();

        SharedPreferences prefs = getSharedPreferences("AppPrefs", MODE_PRIVATE);
        String phoneNumber = prefs.getString("phone_number", "");

        if (phoneNumber.isEmpty()) {
            return; // No number saved
        }

        if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            return; // Permission not granted
        }

        try {
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(phoneNumber, null,
                    "Low inventory alert: " + itemName + " is running low.",
                    null, null);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Load inventory dynamically
    private void loadInventory() {

        Cursor cursor = dbHelper.getAllItems();

        inventoryItems.clear();

        // Load database records into the ArrayList
        if (cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(
                        cursor.getColumnIndexOrThrow(DatabaseHelper.COL_ITEM_ID));

                String name = cursor.getString(
                        cursor.getColumnIndexOrThrow(DatabaseHelper.COL_ITEM_NAME));

                int qty = cursor.getInt(
                        cursor.getColumnIndexOrThrow(DatabaseHelper.COL_QUANTITY));

                InventoryItem item = new InventoryItem(id, name, qty);
                inventoryItems.add(item);

            } while (cursor.moveToNext());
        }

        cursor.close();

        displayInventory(inventoryItems);
    }

    // Display the provided inventory collection on the screen.
    private void displayInventory(ArrayList<InventoryItem> itemsToDisplay) {

        inventoryContainer.removeAllViews();

        for (InventoryItem item : itemsToDisplay) {

            int id = item.getId();
            String name = item.getName();
            int qty = item.getQuantity();

            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setPadding(8, 8, 8, 8);

            TextView nameView = new TextView(this);
            nameView.setLayoutParams(new LinearLayout.LayoutParams(
                    0, LinearLayout.LayoutParams.WRAP_CONTENT, 2));
            nameView.setText(name);

            TextView qtyView = new TextView(this);
            qtyView.setLayoutParams(new LinearLayout.LayoutParams(
                    0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));
            qtyView.setText(String.valueOf(qty));

            Button editButton = new Button(this);
            editButton.setText("EDIT");

            editButton.setOnClickListener(v -> {
                editingItemId = id;
                editName.setText(name);
                editQty.setText(String.valueOf(qty));
            });

            Button deleteButton = new Button(this);
            deleteButton.setText("X");

            deleteButton.setOnClickListener(v -> {
                dbHelper.deleteItem(id);
                loadInventory();
            });

            row.addView(nameView);
            row.addView(qtyView);
            row.addView(editButton);
            row.addView(deleteButton);

            inventoryContainer.addView(row);
        }
    }

    // Search inventory by item name using a linear search.
    // Time complexity: O(n) because each inventory item may need to be checked.
    private void searchInventory(String searchText) {

        if (searchText.isEmpty()) {
            displayInventory(inventoryItems);
            return;
        }

        ArrayList<InventoryItem> searchResults = new ArrayList<>();

        // Linear search through the inventory collection.
        // Worst-case time complexity: O(n).
        for (InventoryItem item : inventoryItems) {

            if (item.getName().toLowerCase()
                    .contains(searchText.toLowerCase())) {

                searchResults.add(item);
            }
        }

        displayInventory(searchResults);
    }

    // Sort inventory from lowest to highest quantity.
    // Time complexity: O(n log n) for Java's list sorting implementation.
    private void sortInventoryByQuantity() {

        ArrayList<InventoryItem> sortedItems =
                new ArrayList<>(inventoryItems);

        sortedItems.sort((item1, item2) ->
                Integer.compare(
                        item1.getQuantity(),
                        item2.getQuantity()));

        displayInventory(sortedItems);
    }

    // Filter inventory to show items at or below the low-stock threshold.
    // Time complexity: O(n) because each inventory item may need to be checked.
    private void filterLowStock() {

        SharedPreferences prefs =
                getSharedPreferences("AppPrefs", MODE_PRIVATE);

        int threshold = prefs.getInt("low_threshold", 5);

        ArrayList<InventoryItem> lowStockItems = new ArrayList<>();

        for (InventoryItem item : inventoryItems) {

            if (item.getQuantity() <= threshold) {
                lowStockItems.add(item);
            }
        }

        displayInventory(lowStockItems);
    }


}