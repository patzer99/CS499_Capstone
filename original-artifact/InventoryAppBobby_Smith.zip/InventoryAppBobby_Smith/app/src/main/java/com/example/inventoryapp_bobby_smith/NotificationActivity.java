package com.example.inventoryapp_bobby_smith;

import android.Manifest;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class NotificationActivity extends AppCompatActivity {

    private static final int SMS_PERMISSION_CODE = 200;

    private TextView status;

    private EditText editThreshold;
    private EditText editPhone;
    private SharedPreferences prefs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notification);

        status = findViewById(R.id.textPermissionStatus);
        Button grantButton = findViewById(R.id.buttonGrantPermission);
        Button sendButton = findViewById(R.id.buttonSendNotification);
        Button saveButton = findViewById(R.id.buttonSaveNumber);
        editPhone = findViewById(R.id.editPhoneNumber);

        prefs = getSharedPreferences("AppPrefs", MODE_PRIVATE);

        editThreshold = findViewById(R.id.editThreshold);
        Button saveThresholdButton = findViewById(R.id.buttonSaveThreshold);

        // Load saved threshold (default 5)
        int savedThreshold = prefs.getInt("low_threshold", 5);
        editThreshold.setText(String.valueOf(savedThreshold));

        saveThresholdButton.setOnClickListener(v -> {

            String thresholdText = editThreshold.getText().toString().trim();

            if (!thresholdText.isEmpty()) {
                int threshold = Integer.parseInt(thresholdText);
                prefs.edit().putInt("low_threshold", threshold).apply();
                Toast.makeText(this, "Threshold saved", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Enter a valid threshold", Toast.LENGTH_SHORT).show();
            }
        });

        // Load saved phone number
        editPhone.setText(prefs.getString("phone_number", ""));

        updatePermissionStatus();

        // Save phone number
        saveButton.setOnClickListener(v -> {
            String phone = editPhone.getText().toString().trim();

            if (!phone.isEmpty()) {
                prefs.edit().putString("phone_number", phone).apply();
                Toast.makeText(this, "Phone number saved", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Enter a valid phone number", Toast.LENGTH_SHORT).show();
            }
        });

        // Request SMS permission
        grantButton.setOnClickListener(v -> {
            if (ContextCompat.checkSelfPermission(this,
                    Manifest.permission.SEND_SMS)
                    != PackageManager.PERMISSION_GRANTED) {

                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.SEND_SMS},
                        SMS_PERMISSION_CODE);
            }
        });

        // Send test SMS
        sendButton.setOnClickListener(v -> {

            if (ContextCompat.checkSelfPermission(this,
                    Manifest.permission.SEND_SMS)
                    == PackageManager.PERMISSION_GRANTED) {

                String phoneNumber = prefs.getString("phone_number", "");

                if (phoneNumber.isEmpty()) {
                    Toast.makeText(this, "Save a phone number first", Toast.LENGTH_SHORT).show();
                    return;
                }

                try {
                    SmsManager smsManager = SmsManager.getDefault();
                    smsManager.sendTextMessage(phoneNumber, null,
                            "Test notification from Inventory App",
                            null, null);

                    Toast.makeText(this, "Test SMS Sent!", Toast.LENGTH_SHORT).show();

                } catch (Exception e) {
                    Toast.makeText(this, "SMS Failed", Toast.LENGTH_SHORT).show();
                }

            } else {
                Toast.makeText(this, "SMS Permission Not Granted", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void updatePermissionStatus() {
        if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED) {

            status.setText("Permission Status: Granted");

        } else {
            status.setText("Permission Status: Not Granted");
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           String[] permissions,
                                           int[] grantResults) {

        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == SMS_PERMISSION_CODE) {

            if (grantResults.length > 0
                    && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                Toast.makeText(this, "Permission Granted", Toast.LENGTH_SHORT).show();

            } else {
                Toast.makeText(this, "Permission Denied", Toast.LENGTH_SHORT).show();
            }

            updatePermissionStatus();
        }
    }
}