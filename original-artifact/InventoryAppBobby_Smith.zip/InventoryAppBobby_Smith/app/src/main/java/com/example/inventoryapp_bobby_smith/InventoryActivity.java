package com.example.inventoryapp_bobby_smith;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.widget.Button;
import android.database.Cursor;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.EditText;
import android.Manifest;
import android.content.pm.PackageManager;
import android.telephony.SmsManager;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import android.widget.Toast;
import android.content.SharedPreferences;

public class InventoryActivity extends AppCompatActivity {

    private DatabaseHelper dbHelper;
    private LinearLayout inventoryContainer;

    private static final int SMS_PERMISSION_CODE = 101;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);

        dbHelper = new DatabaseHelper(this);
        inventoryContainer = findViewById(R.id.inventoryContainer);

        loadInventory();

        Button addButton = findViewById(R.id.buttonAddItem);
        EditText editName = findViewById(R.id.editNewItem);
        EditText editQty = findViewById(R.id.editNewQty);

        addButton.setOnClickListener(v -> {

            String name = editName.getText().toString().trim();
            String qtyText = editQty.getText().toString().trim();

            if (!name.isEmpty() && !qtyText.isEmpty()) {

                int qty = Integer.parseInt(qtyText);
                dbHelper.addItem(name, qty);

                // Low inventory trigger
                SharedPreferences prefs = getSharedPreferences("AppPrefs", MODE_PRIVATE);
                int threshold = prefs.getInt("low_threshold", 5);

                if (qty <= threshold) {
                    sendLowInventoryAlert(name);
                }

                editName.setText("");
                editQty.setText("");

                loadInventory();
            }
        });

        Button notificationButton = findViewById(R.id.buttonNotifications);

        notificationButton.setOnClickListener(v -> {
            Intent intent = new Intent(InventoryActivity.this, NotificationActivity.class);
            startActivity(intent);
        });
    }

    // Permission request
    private void checkSmsPermission() {
        ActivityCompat.requestPermissions(this,
                new String[]{Manifest.permission.SEND_SMS},
                SMS_PERMISSION_CODE);
    }

    // Handle permission result safely
    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           String[] permissions,
                                           int[] grantResults) {

        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == SMS_PERMISSION_CODE) {
            if (grantResults.length > 0
                    && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                // Permission granted — user can now trigger SMS next time
            } else {
                // Permission denied — app continues normally
            }
        }
    }

    // SMS sending method
    private void sendLowInventoryAlert(String itemName) {

        // Always show visible alert (for grading / demo)
        Toast.makeText(this,
                "Low Inventory Alert for " + itemName,
                Toast.LENGTH_LONG).show();

        SharedPreferences prefs = getSharedPreferences("AppPrefs", MODE_PRIVATE);
        String phoneNumber = prefs.getString("phone_number", "");

        if (phoneNumber.isEmpty()) {
            return; // No number saved
        }

        if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            return; // Permission not granted
        }

        try {
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(phoneNumber, null,
                    "Low inventory alert: " + itemName + " is running low.",
                    null, null);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Load inventory dynamically
    private void loadInventory() {

        inventoryContainer.removeAllViews();

        Cursor cursor = dbHelper.getAllItems();

        if (cursor.moveToFirst()) {
            do {

                int id = cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_ITEM_ID));
                String name = cursor.getString(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_ITEM_NAME));
                int qty = cursor.getInt(cursor.getColumnIndexOrThrow(DatabaseHelper.COL_QUANTITY));

                LinearLayout row = new LinearLayout(this);
                row.setOrientation(LinearLayout.HORIZONTAL);
                row.setPadding(8, 8, 8, 8);

                TextView nameView = new TextView(this);
                nameView.setLayoutParams(new LinearLayout.LayoutParams(
                        0, LinearLayout.LayoutParams.WRAP_CONTENT, 2));
                nameView.setText(name);

                TextView qtyView = new TextView(this);
                qtyView.setLayoutParams(new LinearLayout.LayoutParams(
                        0, LinearLayout.LayoutParams.WRAP_CONTENT, 1));
                qtyView.setText(String.valueOf(qty));

                Button deleteButton = new Button(this);
                deleteButton.setText("X");

                deleteButton.setOnClickListener(v -> {
                    dbHelper.deleteItem(id);
                    loadInventory();
                });

                row.addView(nameView);
                row.addView(qtyView);
                row.addView(deleteButton);

                inventoryContainer.addView(row);

            } while (cursor.moveToNext());
        }

        cursor.close();
    }
}